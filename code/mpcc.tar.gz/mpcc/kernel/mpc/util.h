
#include <linux/printk.h>

#ifndef MPC_UTIL_H
#define MPC_UTIL_H

#ifndef USEC_PER_SEC
#define USEC_PER_SEC 1000000
#endif

#define MPC_ONE 1024

#endif /* end of include guard: MPC_UTIL_H */
