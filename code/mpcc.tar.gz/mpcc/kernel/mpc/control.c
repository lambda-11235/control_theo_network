
#include <linux/limits.h>

#include "control.h"
#include "util.h"


// Approximation of 0 RTT (500 us).
#define LOW_THRESH_RTT 500

#define PROBE_RTTS 8
#define STABLE_RTTS 128

s64 sqr(s64 x) { return x*x; }
s64 cube(s64 x) { return x*x*x; }

static inline s64 wma(s64 weight, s64 avg, s64 x)
{
	return ((MPC_ONE - weight)*avg + weight*x)/MPC_ONE;
}

static s64 control_handle_probing(struct model *md, s64 time, s64 rate_meas, s64 rtt_meas, s64 drops);
static void control_update_rb(struct model *md, s64 time_delta, s64 rate_meas, s64 rtt_meas);
static void control_update_stats(struct model *md, s64 rate_meas, s64 rtt_meas);


u64 control_process(struct model *md, u64 time, u64 rate_meas, u64 rtt_meas,
	u64 drops)
{
	s64 c1 = MPC_ONE - md->c2 - md->c3;
	s64 target_rtt;
	s64 time_delta = time - md->last_time;

	control_update_stats(md, rate_meas, rtt_meas);

	target_rtt = control_handle_probing(md, time, md->rate_set, rtt_meas, drops);

	//printk(KERN_INFO "MPC: md->probing = %d, rtt_meas = %lld, lp = %lld, avg_rtt = %lld, std_rtt = %lld, target_rtt = %lld\n",
	//	md->probing, rtt_meas, md->lp, md->avg_rtt, md->std_rtt, target_rtt);

	if (md->probing_mode == LP_MODE) {
		md->rate_set = md->min_rate;
	} else if (md->probing_mode == LB_MODE) {
		md->rate_set = md->max_rate;
	} else {
		s64 tmp1, tmp2, lambda, denom;

		// NOTE: We use rate_set because rate_meas is not accurate, and
		// rate_set can thus give a better prediction.
		control_update_rb(md, time_delta, md->rate_set, rtt_meas);

		tmp1 = md->c3*sqr(md->lp);
		tmp2 = md->weight*md->c2 + c1;
		lambda = tmp2*(rtt_meas - time_delta) - c1*target_rtt - md->weight*md->c2*md->avg_rtt;
		denom = tmp1 + sqr(time_delta)*tmp2;

		if (denom != 0)
			md->rate_set = (tmp1*md->rate_set - time_delta*md->rb*lambda)/denom;

		md->rate_set = min(max(md->min_rate, md->rate_set), md->max_rate);
	}

	md->stats.rtt_pred_us = md->l0;
	if (0 < md->rb)
		md->stats.rtt_pred_us += (md->rate_set - md->rb)/md->rb;
	md->stats.rtt_pred_us = max((s64) 0, md->stats.rtt_pred_us);

	md->stats.rate_meas = rate_meas;
	md->stats.rate_set = md->rate_set;
	md->stats.rtt_meas_us = rtt_meas;
	md->stats.lp = md->lp;
	md->stats.lb = md->lb;
	md->stats.rb = md->rb;
	md->stats.x = md->l0 - md->lp;

	md->last_drops = drops;
	md->last_time = time;

	return md->rate_set;
}


static s64 control_handle_probing(struct model *md, s64 time, s64 rate_meas, s64 rtt_meas, s64 drops)
{
	if (drops > md->last_drops) {
		md->probing_mode = LP_MODE;
		md->probe_timeout = time + PROBE_RTTS*md->avg_rtt;
	} else if (md->probe_timeout <= time) {
		if (md->probing_mode == STABLE_MODE) {
			md->probing_mode = LB_MODE;
		} else if (md->probing_mode == LB_MODE) {
			md->probing_mode = LP_MODE;
		} else {
			md->probing_mode = STABLE_MODE;
		}

		if (md->probing_mode != STABLE_MODE) {
			md->probe_timeout = time + PROBE_RTTS*md->avg_rtt;
		} else {
			md->probe_timeout = time + STABLE_RTTS*md->avg_rtt;
		}
	}

	if (rtt_meas < md->lp) {
		md->lp = rtt_meas;
		md->lp_time = time;
	} else if (rtt_meas > md->lb) {
		md->lb = rtt_meas;
		md->lb_time = time;
	} else {
		s64 tf = md->strides*(STABLE_RTTS + PROBE_RTTS)*md->avg_rtt;
		s64 diff_lp = (md->avg_rtt - md->lp)*(time - md->lp_time)/tf;
		s64 diff_lb = (md->avg_rtt - md->lb)*(time - md->lb_time)/tf;

		if (diff_lp != 0)
			md->lp_time = time;

		if (diff_lb != 0)
			md->lb_time = time;

		md->lp += diff_lp;
		md->lb += diff_lb;
	}

	// Set target RTT to appropriate value.
	return md->lp + (md->lb - md->lp)*md->buffer_fill/MPC_ONE;
}


static void control_update_rb(struct model *md, s64 time_delta, s64 rate_meas, s64 rtt_meas)
{
	s64 t;

	md->l1 = md->l0;
	md->l0 = rtt_meas;

	if (0 != md->rb && 0 != md->avg_rtt && md->probing_mode != LP_MODE) {
		// Gradient descent that minimizes (l - lhat)^2.
		t = (md->l1 - md->l0 - time_delta) + rate_meas/md->rb*time_delta;
		t = 2*rate_meas*time_delta*t/sqr(md->rb);

		// Adjust cost function to in the same units as the rate.
		t = t*sqr(md->avg_rate)/sqr(md->avg_rtt);

		md->rb = (MPC_ONE*md->rb + md->learn_rate*t)/MPC_ONE;
	}

	//t1 = time_delta + md->l0 - md->l1;

	//if (t1 != 0)
	//	md->rb = rate_meas*time_delta/t1;

	md->rb = min(max(md->min_rate, md->rb), md->max_rate);
}


static void control_update_stats(struct model *md, s64 rate_meas, s64 rtt_meas)
{
	md->avg_rate = wma(md->weight, md->avg_rate, rate_meas);
	md->avg_rtt = wma(md->weight, md->avg_rtt, rtt_meas);
	md->var_rtt = wma(md->weight, md->var_rtt, sqr(rtt_meas - md->avg_rtt));
	md->std_rtt = int_sqrt(md->var_rtt);
}
