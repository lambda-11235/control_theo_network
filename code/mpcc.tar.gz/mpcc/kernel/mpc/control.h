
#include "model.h"

#ifndef CONTROL_H
#define CONTROL_H

// Update model and return the next pacing rate.
//
// @param time The current time in us.
// @param rate_meas The measured rate in Mbytes/s
// @param rtt_meas RTT measured in us.
// @param drops The cumulative number of drops for this flow.
u64 control_process(struct model *md, u64 time, u64 rate_meas, u64 rtt_meas,
	u64 drops);

#endif /* end of include guard: CONTROL_H */
