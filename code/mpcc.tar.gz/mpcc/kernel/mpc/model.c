
#include <linux/slab.h>

#include "model.h"


int model_init(struct model *md, struct mpc_settings *settings)
{
	int res = model_change(md, settings);

	model_reset(md);

	return res;
}

int model_change(struct model *md, struct mpc_settings *settings)
{
	md->buffer_fill = settings->buffer_fill*MPC_ONE/1024;
	md->weight = settings->weight*MPC_ONE/1024;
	md->learn_rate = settings->learn_rate*MPC_ONE/1024;
	md->strides = settings->strides;
	md->min_rate = settings->min_rate >> 3;
	md->max_rate = settings->max_rate >> 3;
	md->c2 = settings->c2*MPC_ONE/1024;
	md->c3 = settings->c3*MPC_ONE/1024;

	return 0;
}

void model_release(struct model *md)
{
}

void model_reset(struct model *md)
{
	md->rate_set = 0;
	md->last_drops = 0;
	md->last_time = 0;
	md->lp_time = 0;
	md->lb_time = 0;

	md->avg_rate = 0;
	md->avg_rtt = 0;
	md->var_rtt = 0;
	md->std_rtt = 0;

	md->l0 = 0;
	md->l1 = 0;

	md->rb = 0;
	md->lp = 0;
	md->lb = 0;

	md->probing_mode = STABLE_MODE;
	md->probe_target = 0;
	md->probe_timeout = 0;
}
