
#include "dfs.h"
#include "util.h"
#include "sysfs.h"

#ifndef MODEL_H
#define MODEL_H

enum mode {LP_MODE, LB_MODE, STABLE_MODE};

struct model {
	struct mpc_dfs_stats stats;

	// Rates are in MB/s, and RTTs are in us. Fractions are out of MPC_ONE.
	//
	// NOTE: Order matters here. Generally we want it to go from larger to
	// smaller data types to properly handle alignment.

	s64 min_rate;
	s64 max_rate;
	s64 rate_set;
	s64 last_drops;
	s64 last_time;
	s64 lp_time;
	s64 lb_time;

	// How much the buffers should be filled.
	u16 buffer_fill;
	s64 avg_rate;
	s64 avg_rtt;
	s64 var_rtt;
	s64 std_rtt;

	s64 l0;
	s64 l1;
	s64 rb;
	s64 lp;
	s64 lb;

	u16 weight;
	u16 learn_rate;
	u16 strides; // Number of RTTs before lP and lB decay by 63%.

	// RTT variance and control action relative weights.
	u16 c2;
	u16 c3;

	enum mode probing_mode;
	s64 probe_target;
	s64 probe_timeout;
};

int model_init(struct model *md, struct mpc_settings *settings);

int model_change(struct model *md, struct mpc_settings *settings);

void model_release(struct model *md);

void model_reset(struct model *md);

#endif /* end of include guard: MODEL_H */
