#!/usr/bin/env python3

import argparse
import matplotlib
import matplotlib.pyplot as plt

from data import Data

bwctlStartTime = 0

parser = argparse.ArgumentParser(description="Plots test results.")
parser.add_argument('test', type=str,
        help="The name of the test to run.")
parser.add_argument('-o', '--output', type=str,
        help="Sets output file base name.")
parser.add_argument('-e', '--output-extension', type=str, default="pdf",
        help="Sets the extension for output files (i.e. pdf, png, etc.).")
parser.add_argument('-q', '--limit-quantile', type=float,
        help="Limits output range to within double of a certain quantile.")
parser.add_argument('-s', '--stream', type=int, default=0,
        help="Select the iperf stream to use.")
parser.add_argument('-a', '--all-modules', action='store_true',
        help="Plot all module data.")
parser.add_argument('-i', '--with-id', type=int, default=None,
        help="Plot all module data with a certain id.")
args = parser.parse_args()


data = Data(args.test)

stream = data.streams[args.stream]

sk = stream.socket.mode()[0]
c = data.connections.query("socket == @sk")

if args.all_modules:
    module = data.module
elif args.with_id is not None:
    q = 'id == "' + str(args.with_id) + '"'
    module = data.module.query(q)
else:
    lport = c.local_port.iloc[0]
    q = 'lport == ' + str(lport)
    module = data.module.query(q)

rtt_adj = stream.rtt/1000
rttVar_adj = stream.rttvar/1000
rate_adj = stream.bits_per_second/(1<<20)
cwnd_adj = stream.snd_cwnd/(1<<10)

mpcRTT_adj = module.rtt_meas_us/1000
mpcRTTPred_adj = module.rtt_pred_us/1000
mpcRateM_adj = 8*module.rate_meas
mpcRateS_adj = 8*module.rate_set


bwfig, bwax = plt.subplots(2, 2, figsize=(10, 10))
ax1 = bwax[0][0]
ax2 = ax1.twinx()
ax3 = bwax[0][1]
ax4 = ax3.twinx()
ax5 = bwax[1][0]

modfig, modax = plt.subplots(2, 2, figsize=(10, 10))
ax6 = modax[0][0]
#ax7 = ax6.twinx()
ax8 = modax[0][1]
ax9 = ax8.twinx()
ax10 = modax[1][0]
ax11 = ax10.twinx()
ax12 = modax[1][1]
ax13 = ax12.twinx()

ax1.plot(stream.start, rtt_adj, 'r', label = 'RTT')
ax1.set_xlabel('Time (s)')
ax1.set_ylabel('RTT (ms)')

ax2.plot(stream.start, rttVar_adj, 'g', label = 'RTT Variance')
ax2.set_xlabel('Time (s)')
ax2.set_ylabel('RTT variance (ms)')

ax3.plot(stream.start, rate_adj, 'b', label = 'Rate')
ax3.set_xlabel('Time (s)')
ax3.set_ylabel('Rate (mbit/s)')

ax4.plot(stream.start, stream.retransmits, 'y', label = 'Retransmits')
ax4.set_ylabel('Retransmits')

ax5.plot(stream.start, cwnd_adj, 'c', label = 'Congestion Window')
ax5.set_xlabel('Time (s)')
ax5.set_ylabel('Congestion Window (kbytes)')


ax6.plot(module.time, mpcRTT_adj, 'or', label = 'MPC Observed RTT')
ax6.plot(module.time, mpcRTTPred_adj, 'y', label = 'MPC Predicted RTT')
ax6.set_xlabel('Time (s)')
ax6.set_ylabel('MPC RTT (ms)')

ax8.plot(module.time, mpcRateS_adj, 'ob', label = 'MPC Set Rate')
ax8.set_xlabel('Time (s)')
ax8.set_ylabel('MPC Set Rate (mbit/s)')

ax9.plot(module.time, mpcRateM_adj, 'or', label = 'MPC Observed Rate')
ax9.set_ylabel('MPC Measured Rate (mbit/s)')

ax10.plot(module.time, module.lp/1000, '--b', label = 'lp')
ax10.set_ylabel('lp (ms)')

ax11.plot(module.time, module.lb/1000, '--m', label = 'lb')
ax11.set_ylabel('lb (ms)')

ax12.plot(module.time, 8*module.rb, '--g', label = 'rb')
ax12.set_xlabel('Time (s)')
ax12.set_ylabel('rb (mbits/s)')

ax13.plot(module.time, module.x/1000, '--y', label = 'x')
ax13.set_ylabel('x (ms)')


if args.limit_quantile is not None:
    ax1.set_ylim(0, rtt_adj.quantile(args.limit_quantile)*2)
    ax2.set_ylim(0, rttVar_adj.quantile(args.limit_quantile)*2)
    ax3.set_ylim(0, rate_adj.quantile(args.limit_quantile)*2)
    ax4.set_ylim(0, stream.retransmits.quantile(args.limit_quantile)*2)
    ax5.set_ylim(0, cwnd_adj.quantile(args.limit_quantile)*2)

    if len(mpcRTT_adj) > 0:
        q1 = mpcRTT_adj.quantile(args.limit_quantile)
        q2 = mpcRTTPred_adj.quantile(args.limit_quantile)
        ax6.set_ylim(0, min(q1, q2)*2)

    if len(mpcRateS_adj) > 0:
        ax8.set_ylim(0, mpcRateS_adj.quantile(args.limit_quantile)*2)
        ax9.set_ylim(0, mpcRateS_adj.quantile(args.limit_quantile)*2)

bwfig.legend()
bwfig.suptitle("BWCTL")

modfig.legend()
modfig.suptitle("Kernel Module")


if args.output is not None:
    bwfig.savefig(args.output + "-test." + args.output_extension)
    modfig.savefig(args.output + "-module." + args.output_extension)
else:
    plt.show()
