
#include <cstdint>

#include <vector>

namespace MUDT {
    const uint32_t maxPayloadLength = 512;

    struct Header {
        uint32_t seq;
        uint32_t ack;
        uint32_t rwnd;
        uint32_t length;
    };

    typedef std::vector<uint8_t> Data;

    struct Packet {
        Header header;
        Data data;
    };
}
