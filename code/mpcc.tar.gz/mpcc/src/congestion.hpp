
#ifndef CONGESTION_HPP
#define CONGESTION_HPP


namespace MUDT {
    struct Record {
        double setRate;
        double lhat, targetRTT;
        double avgRTT, varRTT, stdRTT;
        double rB, lB, lP;
    };


    /**
     * Base class for rate based congestion algorithms.
     */
    class Congestion {
        public:
            /**
             * Determine if a packet should be sent.
             *
             * @param packetLength The associated packet length.
             * @param time Time in seconds. Doesn't matter where it starts as
             *             long as times have a common start time.
             */
            virtual bool sendPacket(unsigned long packetLength, double time) = 0;

            /**
             * Determine when to check for a packet send.
             *
             * @param packetLength The associated packet length.
             * @param time Time in seconds. Doesn't matter where it starts as
             *             long as times have a common start time.
             */
            virtual double wakeupTime(unsigned long packetLength, double time) = 0;

            virtual void send(unsigned long packetLength, double time) {}
            virtual void loss(unsigned long packetLength, double time) {}

            /**
             * Process an ACK.
             *
             * @param packetLength The associated packet length.
             * @param time Time in seconds. Doesn't matter where it starts as
             *             long as times have a common start time.
             * @param rtt The observed RTT.
             */
            virtual void ack(unsigned long packetLength, double time, double rtt) {}

            virtual Record getRecord() {
                return Record{0, 0, 0, 0, 0, 0, 0};
            }
    };
}


#endif /* end of include guard: CONGESTION_HPP */
