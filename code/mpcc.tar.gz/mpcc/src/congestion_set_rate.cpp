
#include "congestion_set_rate.hpp"


namespace MUDT {
    CongestionSetRate::CongestionSetRate(double rate) {
        this->rate = rate;
        this->lastRTT = 0;
    }


    bool CongestionSetRate::sendPacket(unsigned long packetLength, double time) {
        return time >= rateTimer.nextSendTime();
    }

    double CongestionSetRate::wakeupTime(unsigned long packetLength, double time) {
        return rateTimer.nextSendTime();
    }

    void CongestionSetRate::send(unsigned long packetLength, double time) {
        rateTimer.send(rate, packetLength, time, lastRTT);
    }

    void CongestionSetRate::ack(unsigned long packetLength, double time, double rtt) {
        lastRTT = rtt;
    }
}
