
#include <climits>
#include <iostream>
#include <limits>

#include "controller.hpp"


namespace MUDT {
    double wma(double weight, double avg, double x) {
        return (1 - weight)*avg + weight*x;
    }

    inline double sqr(double x) { return x*x; }
    inline double cube(double x) { return x*x*x; }


    Controller::Controller(double minRate, double maxRate, double lr,
            double c2, double c3, double weight,
            double cycleTime, double cycleDiv, double bufferFill,
            double strides) {
        this->minRate = minRate;
        this->maxRate = maxRate;
        this->lr = lr;
        this->c1 = 1 - c2 - c3;
        this->c2 = c2;
        this->c3 = c3;
        this->weight = weight;
        this->cycleTime = cycleTime;
        this->cycleDiv = cycleDiv;
        this->bufferFill = bufferFill;
        this->strides = strides;

        this->lastTime = 0;

        reset();
    }

    void Controller::reset() {
        this->lPTime = 0;
        this->lBTime = 0;

        this->cycleTimeAdj = this->cycleTime;
        this->targetRTT = 0;
        this->targetTime = 0;

        this->setRate = this->maxRate;
        this->l0 = 0;
        this->l1 = 0;

        this->lhat = 0;
        this->avgRTT = 0;
        this->varRTT = 0;
        this->stdRTT = 0;
        this->rB = 0;
        this->lB = 0;
        this->lP = std::numeric_limits<double>::infinity();
    };


    bool Controller::sendPacket(unsigned long packetLength, double time) {
        return time >= rateTimer.nextSendTime();
    }


    double Controller::wakeupTime(unsigned long packetLength, double time) {
        return rateTimer.nextSendTime();
    }


    void Controller::send(unsigned long packetLength, double time) {
        rateTimer.send(setRate, packetLength, time, avgRTT);
    }


    void Controller::loss(unsigned long packetLength, double time) {
        setRate /= 2;

        double adj = 1 + rand()/(double) RAND_MAX;
        cycleTimeAdj = cycleTime*adj;
        targetTime = time;
    }


    void Controller::ack(unsigned long packetLength, double time, double rtt) {
        double timeDelta = time - lastTime;

        updateStats(setRate, rtt);

        handleProbing(time, setRate, rtt);

        double tmp1, tmp2, lambda, denom;
        updateRB(timeDelta, setRate, rtt);

        tmp1 = c3*sqr(lP);
        tmp2 = weight*c2 + c1;
        lambda = tmp2*(rtt - timeDelta) - c1*targetRTT- weight*c2*avgRTT;
        denom = tmp1 + sqr(timeDelta)*tmp2;

        if (denom != 0)
            setRate = (tmp1*setRate - timeDelta*rB*lambda)/denom;

        setRate = fmin(fmax(minRate, setRate), maxRate);

        lhat = l0;
        if (rB > 0)
            lhat += (setRate - rB)/rB;
        lhat = fmin(fmax(lP, lhat), lB);

        lastTime = time;
    }


    Record Controller::getRecord() {
        Record record;

        record.setRate = setRate;
        record.lhat = lhat;
        record.targetRTT = targetRTT;
        record.avgRTT = avgRTT;
        record.varRTT = varRTT;
        record.stdRTT = stdRTT;
        record.rB = rB;
        record.lB = lB;
        record.lP = lP;

        return record;
    }


    void Controller::handleProbing(double time, double rate, double rtt) {
        if (rtt < lP) {
            lP = rtt;
            lPTime = time;
        } else if (rtt > lB) {
            lB = rtt;
            lBTime = time;
        } else {
            // NOTE: If we solve the diff. eq. that results from below, we find
            // that
            // lP(t) = rtt + (lP(0) - rtt) e^(-t/tf)
            // This means that at tf we can expect only lP to be 63% of the
            // way to avgRTT.
            double tf = strides*cycleTime;
            double diffLP = (avgRTT - lP)*(time - lPTime)/tf;
            double diffLB = (avgRTT - lB)*(time - lBTime)/tf;

            if (diffLP != 0)
                lPTime = time;

            if (diffLB != 0)
                lBTime = time;

            lP += diffLP;
            lB += diffLB;
        }


        double lBMult = 1.0 + 1/sqr(M_E);
        double min = lP;
        double mid = lP + bufferFill*(lB - lP);
        double max = lBMult*lB;

        double x = (time - targetTime)/cycleTimeAdj;
        x = x - floor(x);
        targetRTT = mid + (max - mid)/(sqr(cycleDiv*(1 - x)) + 1) - (mid - min)/(sqr(cycleDiv*x) + 1);
    }


    void Controller::updateRB(double timeDelta, double rate, double rtt) {
        double t;

        l1 = l0;
        l0 = rtt;

        // Estimate rB
        if (rB > 0) {
            double t1 = (l1 - l0 - timeDelta) + rate/rB*timeDelta;
            t = 2*rate*timeDelta*t1/sqr(rB);

            // NOTE: When moving to kernel, move adjustments into main eq. to
            // prevent overflow.
            t *= sqr(avgRate)/sqr(avgRTT);

            //std::cout << t << std::endl;
            rB += lr*t;
        }

        // Exact solution
        //t = timeDelta + l0 - l1;
        //if (t != 0)
        //    rB = (1 - lr)*rB + lr*rate*timeDelta/t;

        rB = fmin(fmax(minRate, rB), maxRate);
    }


    void Controller::updateStats(double rate, double rtt) {
        avgRate = wma(weight, avgRate, rate);

        avgRTT = wma(weight, avgRTT, rtt);
        varRTT = wma(weight, varRTT, sqr(rtt - avgRTT));
        stdRTT = sqrt(varRTT);
    }
}
