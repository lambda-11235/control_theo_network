
#ifndef PID_HPP
#define PID_HPP


namespace MUDT {
    class PID {
        private:
            double kp, ki, kd;
            double minControl, maxControl;
            double target;

            double control;
            double integral;
            double lastError;
            double lastTime;

        public:
            PID(double kp, double ki, double kd, double minControl,
                double maxControl, double target);

            void process(double response, double time);
            double getControl();
            void setTarget(double target);
            double getTarget();
            void reset();
    };
}


#endif /* end of include guard: PID_HPP */
