
#include <cmath>

#include "congestion.hpp"
#include "rate_timer.hpp"

#ifndef CONTROLLER_HPP
#define CONTROLLER_HPP


// Infinite rate/RTT.
const double INF = 1.0e16;

// Approximation of 0 RTT.
const double LOW_THRESH_RTT = 1.0e-8;


namespace MUDT {
    /**
     * Controller to set pacing rate given RTT information.
     */
    class Controller : public Congestion {
        private:
            // Rates are in B/s, times are in seconds, and percentages are out of 1.

            double minRate, maxRate;
            double lr;  // Learning rate
            double c1, c2, c3;
            double weight;
            double cycleTime;
            double cycleDiv;
            double bufferFill;
            double strides;

            double lastTime;
            RateTimer rateTimer;

            double lPTime;
            double lBTime;

            double cycleTimeAdj;
            double cycleDivAdj;
            double targetRTT;
            double targetTime;

            double setRate;
            double l0, l1;

            double lhat;
            double avgRate;
            double avgRTT, varRTT, stdRTT;
            double rB, lB, lP;

        public:
            /**
             * @param minRate Minimum pacing rate to set.
             * @param maxRate Maximum pacing rate to set.
             * @param lr Learning rate for estimating bottleneck rate.
             * @param c2 Wight for standard deviation of RTT in objective function.
             * @param c3 Wight for change in pacing rate in objective function.
             * @param cycleTime
             * @param cycleDiv
             * @param bufferFill
             * @param strides
             */
            Controller(double minRate, double maxRate, double lr,
                    double c2, double c3, double weight,
                    double cycleTime, double cycleDiv, double bufferFill,
                    double strides);

            /**
             * Reset controller to initial values.
             */
            void reset();

            bool sendPacket(unsigned long packetLength, double time);
            double wakeupTime(unsigned long packetLength, double time);

            void send(unsigned long packetLength, double time);
            void loss(unsigned long packetLength, double time);
            void ack(unsigned long packetLength, double time, double rtt);

            Record getRecord();

        private:
            /**
             * Determines the current probing mode, handles transitions, and
             * determines target RTT.
             *
             * @return The target RTT to try to set.
             */
            void handleProbing(double time, double rate, double rtt);

            /**
             * Update estimation of bottleneck rate.
             *
             * @param timeDelta The change in time since the last call.
             * @param rate The observed pacing rate.
             * @param rtt The observed RTT.
             */
            void updateRB(double timeDelta, double rate, double rtt);

            /**
             * Determines if an RTT measurement is an outlier.
             */
            bool outlier(double rtt);

            /**
             * Update statistics information.
             */
            void updateStats(double rate, double rtt);
    };
}


#endif /* end of include guard: CONTROLLER_HPP */
