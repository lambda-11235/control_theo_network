
#include "PID.hpp"

#include <cmath>


namespace MUDT {
    PID::PID(double kp, double ki, double kd, double minControl,
        double maxControl, double target) {
        this->kp = kp;
        this->ki = ki;
        this->kd = kd;
        this->minControl = minControl;
        this->maxControl = maxControl;
        this->target = target;

        this->control = minControl;

        reset();
    }


    void PID::process(double response, double time) {
        double dt = time - lastTime;
        double error = target - response;
        double derror = (error - lastError)/dt;
        integral += error*dt;

        control = kp*error + ki*integral + kd*derror;
        control = fmax(minControl, fmin(control, maxControl));

        lastError = error;
        lastTime = time;
    }


    double PID::getControl() {
        return control;
    }


    void PID::setTarget(double target) {
        this->target = target;
    }


    double PID::getTarget() {
        return target;
    }


    void PID::reset() {
        this->integral = 0;
        this->lastError = 0;
        this->lastTime = 0;
    }
}
