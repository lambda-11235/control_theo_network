
#include <stdio.h>

#include "PIDCongestion.hpp"

namespace MUDT {
    PIDCongestion::PIDCongestion(double kp, double ki, double kd, double minControl,
        double maxControl, double target) : pid(kp, ki, kd, minControl, maxControl, target) {
        lastRTT = 0;
        lP = 1;
        lB = 0;
    }


    bool PIDCongestion::sendPacket(unsigned long packetLength, double time) {
        return time >= rateTimer.nextSendTime();
    }


    double PIDCongestion::wakeupTime(unsigned long packetLength, double time) {
        return rateTimer.nextSendTime();
    }


    void PIDCongestion::send(unsigned long packetLength, double time) {
        rateTimer.send(pid.getControl(), packetLength, time, lastRTT);
    }


    void PIDCongestion::ack(unsigned long packetLength, double time, double rtt) {
        lastRTT = rtt;
        lP = fmin(rtt, lP);
        lB = fmin(rtt, lB);

        pid.process(rtt, time);
    }


    Record PIDCongestion::getRecord() {
        Record record;

        record.targetRTT = pid.getTarget();
        record.lP = lP;
        record.lB = lB;

        return record;
    }
}
