
namespace MUDT {
    class Server {
        public:
            Server(int port);

            int read(char *buf, int size);
    };
}
