
#include <math.h>

#include "rate_estimator.hpp"


namespace MUDT {
    RateEstimator::RateEstimator(double startTime, double resetInterval) {
        this->rate = 0;
        this->procData = 0;
        this->startTime = startTime;
        this->resetInterval = resetInterval;
    }


    void RateEstimator::process(unsigned long data, double time) {
        // It's important that rate is calculated first.
        // This way, on reset, the rate is
        // data/delay.
        rate = procData/(time - startTime);

        if (time > startTime + resetInterval) {
            procData = data;
            startTime = time;
        } else {
            procData += data;
        }
    }


    double RateEstimator::getRate() {
        return rate;
    }


    double RateEstimator::setResetInterval(double resetInterval) {
        this->resetInterval = resetInterval;
    }
}

