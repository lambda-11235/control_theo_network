
#include <cstring>
#include <condition_variable>
#include <mutex>
#include <queue>
#include <string>
#include <thread>

#include <arpa/inet.h>
#include <sys/socket.h>


namespace MUDT {
    class Client {
        private:
            bool running;
            double rate;
            std::queue<Packet> packets;

            int sock;
            struct sockaddr_in address;

            std::condition_variable process;
            std::mutex packetMutex;
            std::thread *deliveryThread;

        public:
            Client(std::string addr, short port);
            ~Client();

            void write(char *buf, unsigned int size);

        private:
            void deliverPackets();
    };
}
