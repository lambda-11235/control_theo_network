
#include <math.h>
#include <iostream>

#include "tahoe.hpp"


namespace MUDT {
    Tahoe::Tahoe(double minRate, double maxRate, unsigned long mss) {
        this->minRate = minRate;
        this->maxRate = maxRate;
        this->mss = mss;
        this->ssthresh = 8;
        this->cwnd = 1;
        this->nextTime = 0;

        this->lastRTT = 0;
    }


    bool Tahoe::sendPacket(unsigned long packetLength, double time) {
        return inflight + packetLength <= cwnd*mss;
    }

    double Tahoe::wakeupTime(unsigned long packetLength, double time) {
        if (lastRTT == 0) {
            return time + 1.0e-7;
        } else {
            return time + packetLength*lastRTT/(cwnd*mss)/2;
        }
    }


    void Tahoe::send(unsigned long packetLength, double time) {
        inflight += packetLength;
    }


    void Tahoe::loss(unsigned long packetLength, double time) {
        inflight -= packetLength;

        ssthresh = cwnd/2;
        ssthresh = ssthresh < 1 ? 1 : ssthresh;

        cwnd = 1;
    }


    void Tahoe::ack(unsigned long packetLength, double time, double rtt) {
        inflight -= packetLength;

        if (time >= nextTime) {
            if (2*cwnd < ssthresh) {
                cwnd *= 2;
            } else {
                cwnd += 1;
            }

            nextTime = time + rtt;
        }

        lastRTT = rtt;
    }


    Record Tahoe::getRecord() {
        Record record;

        record.setRate = cwnd*mss/lastRTT;
        record.targetRTT = 0;

        return record;
    }
}

