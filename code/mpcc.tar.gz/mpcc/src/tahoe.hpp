
#include "congestion.hpp"

#ifndef TAHOE_HPP
#define TAHOE_HPP

namespace MUDT {
    /**
     * Controller to set pacing rate given RTT information.
     */
    class Tahoe : public Congestion {
        private:
            double minRate;
            double maxRate;
            unsigned long mss;
            unsigned int ssthresh;
            unsigned int cwnd;
            double nextTime;

            unsigned long inflight;
            double lastRTT;

        public:
            /**
             * @param mss Maximum segment size. Largest amount of data per
             * packet.
             */
            Tahoe(double minRate, double maxRate, unsigned long mss);

            bool sendPacket(unsigned long packetLength, double time);
            double wakeupTime(unsigned long packetLength, double time);

            void send(unsigned long packetLength, double time);
            void loss(unsigned long packetLength, double time);
            void ack(unsigned long packetLength, double time, double rtt);

            Record getRecord();
    };
}

#endif /* end of include guard: TAHOE_HPP */

