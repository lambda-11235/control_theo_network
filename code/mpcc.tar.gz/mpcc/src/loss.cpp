
#include <iostream>

#include "loss.hpp"


namespace MUDT {
    Loss::Loss(double minRate, double maxRate, double lr, double target) {
        this->minRate = minRate;
        this->maxRate = maxRate;
        this->lr = lr;
        this->target = target;

        this->setRate = minRate;
        this->rB = minRate;
    }


    bool Loss::sendPacket(unsigned long packetLength, double time) {
        return time >= rateTimer.nextSendTime();
    }


    double Loss::wakeupTime(unsigned long packetLength, double time) {
        return rateTimer.nextSendTime();
    }


    void Loss::send(unsigned long packetLength, double time) {
        rateTimer.send(setRate, packetLength, time, lastRTT);
    }


    void Loss::loss(unsigned long packetLength, double time) {
        // Update loss rate
        if (time > lossStartTime + lastRTT) {
            lostData = 0;
            lossStartTime = time;
        }

        lostData += packetLength;

    }


    void Loss::ack(unsigned long packetLength, double time, double rtt) {
        lastRTT = rtt;

        // Update control
        double timeDelta = time - lastTime;
        double lossRate = lostData/(time - lossStartTime);

        updateRB(timeDelta, setRate, lossRate);

        setRate -= lr*(setRate - rB - target);
        setRate = fmax(minRate, fmin(setRate, maxRate));

        lastTime = time;
    }


    Record Loss::getRecord() {
        Record record;
        record.targetRTT = 0;
        record.rB = rB;
        return record;
    }


    void Loss::updateRB(double timeDelta, double rate, double lossRate) {
        rB = (1 - lr)*rB + lr*(rate - lossRate);
        rB = fmax(minRate, fmin(rB, maxRate));
    }
}
