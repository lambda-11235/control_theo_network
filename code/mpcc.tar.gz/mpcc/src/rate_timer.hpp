
#ifndef RATE_TIMER_HPP
#define RATE_TIMER_HPP

namespace MUDT {
    /**
     * Helps pace packets by keeping track of when to send packets.
     */
    class RateTimer {
        private:
            unsigned int sentData;
            double sendStartTime;
            double _nextSendTime;

        public:
            RateTimer();

            void send(double rate, double packetLength, double time, double rtt);
            double nextSendTime();
    };
}

#endif /* end of include guard: RATE_TIMER_HPP */
