
#include <math.h>

#include "rate_timer.hpp"


namespace MUDT {
    RateTimer::RateTimer() {
        sentData = 0;
        sendStartTime = 0;
        _nextSendTime = 0;
    }

    void RateTimer::send(double rate, double packetLength, double time, double rtt) {
        if (time > sendStartTime + rtt) {
            sentData = 0;
            sendStartTime = time;
        }

        sentData += packetLength;
        _nextSendTime = fmax(time, sendStartTime + sentData/rate);
        //nextSendTime = time + packetLength/rate;
    }

    double RateTimer::nextSendTime() {
        return _nextSendTime;
    }
}
