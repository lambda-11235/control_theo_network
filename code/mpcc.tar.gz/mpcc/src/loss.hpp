
#include <cmath>

#include "congestion.hpp"
#include "rate_timer.hpp"

#ifndef LOSS_HPP
#define LOSS_HPP


namespace MUDT {
    /**
     * Loss to set pacing rate given RTT information.
     */
    class Loss : public Congestion {
        private:
            // Rates are in B/s, times are in seconds, and percentages are out of 1.
            RateTimer rateTimer;

            double minRate, maxRate;
            double lr;  // Learning rate
            double lastRTT;
            double target;

            double lastTime;

            double lostData;
            double lossStartTime;

            double setRate;
            double rB;

        public:
            /**
             * @param minRate Minimum pacing rate to set.
             * @param maxRate Maximum pacing rate to set.
             * @param lr Learning rate for estimating bottleneck rate.
             * @param weight Weight for moving averages.
             * @param target Target loss rate.
             */
            Loss(double minRate, double maxRate, double lr, double target);

            bool sendPacket(unsigned long packetLength, double time);
            double wakeupTime(unsigned long packetLength, double time);

            void send(unsigned long packetLength, double time);
            void loss(unsigned long packetLength, double time);
            void ack(unsigned long packetLength, double time, double rtt);

            Record getRecord();

        private:
            /**
             * Update estimation of bottleneck rate.
             *
             * @param timeDelta The change in time since the last call.
             * @param rate The observed pacing rate.
             * @param lossRate The rate at which bits/bytes are lost.
             */
            void updateRB(double timeDelta, double rate, double lossRate);
    };
}


#endif /* end of include guard: LOSS_HPP */
