
#include "congestion.hpp"
#include "rate_timer.hpp"

#ifndef CONGESTION_SET_RATE_HPP
#define CONGESTION_SET_RATE_HPP

namespace MUDT {
    /**
     * Controller to set pacing rate given RTT information.
     */
    class CongestionSetRate : public Congestion {
        private:
            double rate;
            double lastRTT;
            RateTimer rateTimer;

        public:
            /**
             * @param rate Pacing rate to set.
             */
            CongestionSetRate(double rate);

            bool sendPacket(unsigned long packetLength, double time);
            double wakeupTime(unsigned long packetLength, double time);

            void send(unsigned long packetLength, double time);
            void ack(unsigned long packetLength, double time, double rtt);
    };
}

#endif /* end of include guard: CONGESTION_SET_RATE_HPP */
