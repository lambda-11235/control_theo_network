
#ifndef RATE_ESTIMATOR_HPP
#define RATE_ESTIMATOR_HPP

namespace MUDT {
    /**
     * Keeps track of delivery rates.
     */
    class RateEstimator {
        private:
            double rate;
            unsigned long procData;
            double startTime;
            double resetInterval;

        public:
            RateEstimator(double startTime, double resetInterval);

            void process(unsigned long data, double time);
            double getRate();
            double setResetInterval(double resetInterval);
    };
}

#endif /* end of include guard: RATE_ESTIMATOR_HPP */

