
#include "packet.hpp"

#include "client.hpp"

namespace MUDT {
    Client::Client(std::string addr, short port) {
        running = true;
        rate = 1.0;

        sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

        if (sock == -1) {
            // TODO
        }

        memset(&address, 0, sizeof(address));
        address.sin_family = AF_INET;
        address.sin_port = htons(port);

        if (inet_aton(addr.c_str(), &address.sin_addr) == 0) {
            // TODO
        }

        deliveryThread = new std::thread(&Client::deliverPackets, this);
    }


    Client::~Client() {
        running = false;
        process.notify_all();
        deliveryThread->join();

        close(sock);

        delete deliveryThread;
    }


    void Client::write(char *buf, unsigned int size) {
        std::lock_guard<std::mutex> lock(packetMutex);
        char *iter;

        // TODO: Estimate MTU
        // Segment data into packets of the right size.
        for (iter = buf; iter < buf + size; iter += maxPayloadLength) {
            unsigned int psize = maxPayloadLength;

            if (iter + psize > buf + size)
                psize = size % maxPayloadLength;

            Header h = {0, 0, 0, psize};
            Packet p = {h, std::vector<uint8_t>(iter, iter + psize)};
            packets.push(p);
        }

        process.notify_all();
    }


    void Client::deliverPackets() {
        while (true) {
            std::unique_lock<std::mutex> lock(packetMutex);
            Packet packet;

            lock.lock();

            while (running && packets.size() == 0) {
                process.wait(lock);
            }

            if (!running) {
                return;
            }

            packet = packets.front();
            packets.pop();

            if (sendto(sock, packet.data.data(), packet.header.length, 0,
                        (struct sockaddr*) &address, sizeof(address)) == -1) {
                // TODO
            }

            // TODO: Calculate delay

            lock.unlock();

            // TODO: Sleep
        }
    }
}
