
#include <math.h>

#include "congestion.hpp"
#include "PID.hpp"
#include "rate_timer.hpp"


#ifndef PID_CONGESTION_HPP
#define PID_CONGESTION_HPP


const unsigned int COUNTER_START = 1 << 25;


namespace MUDT {
    class PIDCongestion : public Congestion {
        private:
            PID pid;
            double lastRTT;
            double lP, lB;
            RateTimer rateTimer;

        public:
            PIDCongestion(double kp, double ki, double kd, double minControl,
                double maxControl, double target);

            bool sendPacket(unsigned long packetLength, double time);
            double wakeupTime(unsigned long packetLength, double time);

            void send(unsigned long packetLength, double time);
            void ack(unsigned long packetLength, double time, double rtt);

            Record getRecord();
    };
}


#endif /* end of include guard: PID_CONGESTION_HPP */

