#!/usr/bin/env python3

import argparse
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt

from common import *

parser = argparse.ArgumentParser(description="Plot overlain rates of multiple flows.")
parser.add_argument('output_file', type=str,
        help="File to output plot to.")
parser.add_argument('data_file', type=str, nargs='+',
        help="The data file to plot from.")
parser.add_argument('-s', '--subsamples', type=int,
        help="Number of subsamples to take (default: no subsampling).")
args = parser.parse_args()

mpl.style.use('seaborn-bright')
mpl.rc('figure', dpi=200)
mpl.rc('axes', prop_cycle=mpl.cycler('color', ['#000044', '#FF2222', '#88FFBB', '#8800FF']))


### Rates ###
fig = plt.figure()
ax = fig.add_subplot(111)

upperYLim = 0
flowNum = 1


for f in args.data_file:
    df = pd.read_csv(f)
    df = df.replace([-np.inf, np.inf], np.nan)

    if args.subsamples is not None:
        df = subsampleByTime(df, args.subsamples)

    upperYLim = max(upperYLim, yUpperLim(df['setRate']))

    ax.plot('time', 'setRate', data=df, label=f"Flow {flowNum}")
    flowNum += 1

ax.set_ylim(0, upperYLim)
ax.set_xlabel("Time (s)")
ax.set_ylabel("Rate (Gbps)")
ax.grid()
ax.legend()

fig.savefig(args.output_file, bbox_inches='tight')
