
import numpy as np
import pandas as pd

def yUpperLim(xs):
    return min(3*(xs.mean() + xs.std()), 1.1*xs.max())

def yUpperLimMany(xss):
    return max(map(yUpperLim, xss))

def aggFun(xs):
    mn, q1, q2, q3, mx = np.quantile(xs, [0, 0.25, 0.5, 0.75, 1])
    iqr = q3 - q1

    if mn < q1 - 1.5*iqr:
        return mn
    elif mx > q3 + 1.5*iqr:
        return mx
    else:
        return q2


def subsampleByTime(data, samples):
    return data.groupby(pd.cut(data['time'], samples)).mean()
    #return data.groupby(pd.cut(data['time'], samples)).aggregate(aggFun)
