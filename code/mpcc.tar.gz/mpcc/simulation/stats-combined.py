#!/usr/bin/env python3

import argparse
import json
import numpy as np
import pandas as pd

parser = argparse.ArgumentParser(description="Statistically analyzes simulation results.")
parser.add_argument('data_file', type=str, nargs='+',
        help="The data file to analyze.")
args = parser.parse_args()

for df in args.data_file:
    print(f"========== {df} ==========")
    data = pd.read_csv(df)
    print(data.describe())
    print(f"Losses = {data['total drops'].max()*100/100000000.0}%")
    print()

