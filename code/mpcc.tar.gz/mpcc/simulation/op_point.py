#!/usr/bin/env python3

import argparse
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

parser = argparse.ArgumentParser(description="Determines when combined flows reach bottleneck rate.")
parser.add_argument('data_file', type=str, nargs='+',
        help="The data file to analyze.")
parser.add_argument('--bottleneck-rate', type=float, default=40.0,
        help="The bottleneck rate (default: %(default)s).")
parser.add_argument('--min-rtt', type=float, default=25.0e-3,
        help="The minimum observable RTT (default: %(default)s).")
args = parser.parse_args()

for df in args.data_file:
    data = pd.read_csv(df)
    mx = data['time'].max()
    data = data.groupby(pd.cut(data['time'], np.arange(0, mx, args.min_rtt))).mean()
    data.reset_index(drop=True, inplace=True)

    ops = data.loc[(data['total_rate'] - args.bottleneck_rate).abs() < data['total_rate'].std()/6]

    if len(ops) > 0:
        print(ops.head())
    else:
        print("N/A")
