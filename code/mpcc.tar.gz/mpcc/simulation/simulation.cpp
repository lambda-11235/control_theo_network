
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <queue>
#include <cstring>
#include <random>
#include <vector>

#include <cstdio>

#include "../src/rate_estimator.hpp"

// Congestion Controllers
#include "../src/congestion_set_rate.hpp"
#include "../src/controller.hpp"
#include "../src/loss.hpp"
#include "../src/PIDCongestion.hpp"
#include "../src/tahoe.hpp"

#include "params.h"

void writeFloat(std::ostream& strm, float x) {
    strm.write(reinterpret_cast<char*>(&x), sizeof(x));
}


struct Packet {
    unsigned int sender;
    unsigned long length;
    double enqueueTime;
    double dequeueTime;
};

class EnqueueTimeOrdering {
    public:
        bool operator() (const Packet& lhs, const Packet& rhs) const {
            return (lhs.enqueueTime > rhs.enqueueTime);
        }
};

class DequeueTimeOrdering {
    public:
        bool operator() (const Packet& lhs, const Packet& rhs) const {
            return (lhs.dequeueTime > rhs.dequeueTime);
        }
};


enum Event { ENQUEUE, DEQUEUE, ACK };


//if args.verbose:
//    print("Using LR = {}, C2 = {}, C3 = {}, W = {}, DOWN_RTTS = {}, UP_RTTS = {}, BUFFER FILL = {}".format(
//        args.learning_rate, args.c2, args.c3, args.avg_weight, args.probe_rtts,
//        args.stable_rtts, args.buffer_fill))


int main(int argc, char *argv[]) {
    std::vector<std::ofstream> outputs;
    for (int i = 0; i < NUM_CLIENTS; i++) {
        char fileName[64];

        sprintf(fileName, "data/client-%d.csv", i);
        outputs.push_back(std::ofstream(fileName));

        outputs[i].precision(3);
        outputs[i].flags(std::ios::scientific);

        outputs[i] << "time,rate,rtt,drops,setRate,lhat,targetRTT,avgRTT,varRTT,stdRTT,rB,lB,lP\n";
    }

    std::ofstream combinedOutput("data/combined.csv");
    combinedOutput << "time,total_rate,mean_rtt,total_losses,enqueues,dequeues,acks\n";

    std::vector<MUDT::Congestion*> controllers;
    for (int i = 0; i < NUM_CLIENTS; i++) {
        //controllers.push_back(new MUDT::PIDCongestion(1.0e15, 1.0e16, 0,
        //    MIN_RATES[i%MIN_RATES.size()], MAX_RATES[i%MAX_RATES.size()],
        //    // FIXME: This should not be known
        //    // This is lP + (lB - lP)/4
        //    TRANS_DELAYS[i%TRANS_DELAYS.size()] + BUFFER_LENGTH/BOTTLENECK_RATE/4));

        //controllers.push_back(new MUDT::CongestionSetRate(BOTTLENECK_RATE + 0.1e9));

        //controllers.push_back(new MUDT::Tahoe(
        //    MIN_RATES[i%MIN_RATES.size()], MAX_RATES[i%MAX_RATES.size()],
        //    PACKET_LENGTH_MAX));

        //controllers.push_back(new MUDT::Loss(
        //    MIN_RATES[i%MIN_RATES.size()], MAX_RATES[i%MAX_RATES.size()],
        //    /*LR*/1e-1, 1.0e6));

        controllers.push_back(new MUDT::Controller(
            MIN_RATES[i%MIN_RATES.size()], MAX_RATES[i%MAX_RATES.size()],
            LR, C2, C3, W,
            CYCLE_TIME, CYCLE_DIV, BUFFER_FILL,
            STRIDES));
    }

    std::vector<int> drops(NUM_CLIENTS, 0);
    std::vector<double> rtts(NUM_CLIENTS, 0);
    std::vector<int> sent(NUM_CLIENTS, 0);

    // For tracking the pacing rate
    std::vector<MUDT::RateEstimator*> rateEsts;
    for (int i = 0; i < NUM_CLIENTS; i++) {
        rateEsts.push_back(new MUDT::RateEstimator(0, TRANS_DELAYS[i%TRANS_DELAYS.size()]));
    }

    std::vector<unsigned long> nextPacketLength(NUM_CLIENTS);
    // Contains index of controller and enqueue time.
    std::queue<Packet> buf;
    // Sum of packet sizes in buffer.
    unsigned long bufFill = 0;
    std::priority_queue<Packet, std::vector<Packet>, DequeueTimeOrdering> acks;

    double dequeueTime = 0;

    std::default_random_engine generator;
    std::exponential_distribution<double> rtt_noise_dist(LAMBDA);
    std::normal_distribution<float> packet_length_dist(PACKET_LENGTH_MU, PACKET_LENGTH_SIGMA);

    double time = 0;
    Event nextEvent = ENQUEUE;
    long lastPercComplete = -1;
    unsigned long enqueuesCnt = 0;
    unsigned long dequeuesCnt = 0;
    unsigned long acksCnt = 0;
    unsigned long dataCnt = 0;  // Number of data points logged
    while (time < RUN_TIME) {
        long percComplete = 100*time/RUN_TIME;

        if (percComplete > lastPercComplete) {
            printf("\r%ld%% complete, %ld enqueues, %ld dequeues, %ld acks, %lu%% buffer fill",
                percComplete, enqueuesCnt, dequeuesCnt, acksCnt,
                100*bufFill/BUFFER_LENGTH);
            std::cout << std::flush;
            lastPercComplete = percComplete;
        }


        if (nextEvent == ENQUEUE) {
            enqueuesCnt++;

            for (unsigned int i = 0; i < NUM_CLIENTS; i++) {
                unsigned long length = nextPacketLength[i];

                if (time >= START_TIMES[i%START_TIMES.size()]
                        && controllers[i]->sendPacket(length, time)) {
                    sent[i] += 1;

                    rateEsts[i]->process(length, time);
                    controllers[i]->send(length, time);

                    if (bufFill + length < BUFFER_LENGTH) {
                        bufFill += length;
                        buf.push(Packet{i, length, time, 0});
                    } else {
                        drops[i] += 1;

                        controllers[i]->loss(length, time);
                    }

                    length = packet_length_dist(generator);
                    length = fmax(PACKET_LENGTH_MIN, fmin(length, PACKET_LENGTH_MAX));
                    nextPacketLength[i] = length;
                }
            }
        } else if (nextEvent == DEQUEUE && buf.size() > 0) {
            dequeuesCnt++;

            Packet packet = buf.front();
            buf.pop();
            bufFill -= packet.length;

            dequeueTime = time + packet.length/BOTTLENECK_RATE;

            packet.dequeueTime = time + TRANS_DELAYS[packet.sender%TRANS_DELAYS.size()];

            if (ENABLE_NOISE)
                packet.dequeueTime += fmin(rtt_noise_dist(generator), MAX_NOISE);

            acks.push(packet);
        } else if (nextEvent == ACK && acks.size() > 0) {
            acksCnt++;

            Packet packet = acks.top();
            int i = packet.sender;
            rtts[i] = time - packet.enqueueTime;
            acks.pop();

            controllers[i]->ack(packet.length, time, rtts[i]);

            if (NUM_DATA_POINTS == 0 || time > dataCnt*RUN_TIME/NUM_DATA_POINTS) {
                // Combined stats for all flows
                double combinedRate = 0.0;
                double meanRTT = 0.0;
                unsigned int combinedDrops = 0.0;

                dataCnt++;

                for (size_t i = 0; i < NUM_CLIENTS; i++) {
                    MUDT::Record rec = controllers[i]->getRecord();
                    double rate = rateEsts[i]->getRate();

                    outputs[i] <<
                        time << "," <<
                        rate/1e9 << "," <<
                        rtts[i]*1e3 << "," <<
                        drops[i] << "," <<

                        rec.setRate/1e9 << "," <<
                        rec.lhat*1e3 << "," <<
                        rec.targetRTT*1e3 << "," <<
                        rec.avgRTT*1e3 << "," <<
                        rec.varRTT*1e3 << "," <<
                        rec.stdRTT*1e3 << "," <<
                        rec.rB/1e9 << "," <<
                        rec.lB*1e3 << "," <<
                        rec.lP*1e3 << "\n";

                    combinedRate += rate;
                    combinedDrops += drops[i];
                    meanRTT += rtts[i];
                }

                meanRTT /= NUM_CLIENTS;

                combinedOutput <<
                    time << "," <<
                    combinedRate/1e9 << "," <<
                    meanRTT*1e3 << "," <<
                    combinedDrops << "," <<
                    enqueuesCnt << "," <<
                    dequeuesCnt << "," <<
                    acksCnt << "\n";
            }
        }


        // Determine next event and time
        double nextTime = time;

        if (buf.size() > 0) {
            nextTime = dequeueTime;
            nextEvent = DEQUEUE;
        } else {
            nextTime = controllers[0]->wakeupTime(nextPacketLength[0], time);
            nextEvent = ENQUEUE;
        }

        for (int i = 0; i < NUM_CLIENTS; i++) {
            double wakeup = controllers[i]->wakeupTime(nextPacketLength[i], time);

            if (wakeup > START_TIMES[i%START_TIMES.size()] && wakeup < nextTime) {
                nextTime = wakeup;
                nextEvent = ENQUEUE;
            }
        }

        if (acks.size() > 0 && acks.top().dequeueTime < nextTime) {
            nextTime = acks.top().dequeueTime;
            nextEvent = ACK;
        }

        if (nextTime > time)
            time = nextTime;
    }


    std::cout << std::endl;

    for (auto *ctrl : controllers) {
        delete ctrl;
    }

    for (auto *re : rateEsts) {
        delete re;
    }

    for (int i = 0; i < NUM_CLIENTS; i++) {
        outputs[i].close();
    }

    return 0;
}
