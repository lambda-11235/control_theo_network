#!/usr/bin/env python3

import argparse
import json
import numpy as np
import pandas as pd

parser = argparse.ArgumentParser(description="Statistically analyzes simulation results.")
parser.add_argument('output_csv', type=str,
        help="CSV to output table results to.")
parser.add_argument('data_file', type=str, nargs='+',
        help="The data files to analyze.")
parser.add_argument('-s', '--subsamples', type=int,
        help="Number of subsamples to take (default: don't subsample).")
args = parser.parse_args()


def jain(xs):
    return sum(xs)**2/(len(xs)*sum([x**2 for x in xs]))


report = pd.DataFrame({"time" : []})
rates = []

for f in args.data_file:
    data = pd.read_csv(f)

    if args.subsamples is not None:
        data = data.groupby(pd.cut(data['time'], args.subsamples)).mean()

    report['time'] = data['time']

    rates.append(list(data.rate))

rates = list(zip(*rates))

report["Rates"] = rates
report["MinMax"] = list(map(lambda x: max(x)/min(x) if min(x) > 0 else float('inf'), rates))
report["Jain"] = list(map(jain, rates))
report.to_csv(args.output_csv, index=False)
