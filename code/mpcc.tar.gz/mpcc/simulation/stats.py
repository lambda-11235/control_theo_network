#!/usr/bin/env python3

import argparse
import json
import numpy as np
import pandas as pd

parser = argparse.ArgumentParser(description="Statistically analyzes simulation results.")
parser.add_argument('data_file', type=str, nargs='+',
        help="The data file to analyze.")
parser.add_argument('-f', '--frac-data', type=float, default=0.0,
        help="Fraction of data to start analyzing from (default: %(default)s).")
args = parser.parse_args()

info = []
for df in args.data_file:
    info.append((df, pd.read_csv(df)))

for (df, data) in info:
    data.replace([np.inf, -np.inf], np.nan, inplace=True)

    print(f"===== {df} =====")
    print("=== Statistics ===")
    print(data[int(-len(data)*args.frac_data):].describe())

    print("")
