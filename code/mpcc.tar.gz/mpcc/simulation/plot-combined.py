#!/usr/bin/env python3

import argparse
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt

from common import *

parser = argparse.ArgumentParser(description="Plot")
parser.add_argument('data_file', type=str,
        help="The data file to plot from.")
parser.add_argument('output_prefix', type=str,
        help="Prefix for plot files.")
parser.add_argument('--rate-bounds', type=float, nargs=2,
        help="The bounds for the rate graph.")
parser.add_argument('--rtt-bounds', type=float, nargs=2,
        help="The bounds for the RTT graph.")
parser.add_argument('--losses-bounds', type=float, nargs=2,
        help="The bounds for the losses graph.")
parser.add_argument('-s', '--subsamples', type=int,
        help="Number of subsamples to take (default: no subsampling).")
args = parser.parse_args()

df = pd.read_csv(args.data_file)
df = df.replace([-np.inf, np.inf], np.nan)

if args.subsamples is not None:
    df = subsampleByTime(df, args.subsamples)

mpl.style.use('seaborn-bright')
mpl.rc('figure', dpi=200)


### Rate ###
fig = plt.figure()
ax = fig.add_subplot(111)

if args.rate_bounds is not None:
    ax.set_ylim(args.rate_bounds[0], args.rate_bounds[1])
else:
    ax.set_ylim(0, yUpperLim(df['total_rate']))

ax.plot('time', 'total_rate', data=df, label="Total Rate", color="blue")

ax.set_xlabel("Time (s)")
ax.set_ylabel("Rate (Gbps)")
ax.grid()

fig.savefig(args.output_prefix + "-rate.png", bbox_inches='tight')


### RTT ###
fig = plt.figure()
ax = fig.add_subplot(111)

if args.rtt_bounds is not None:
    ax.set_ylim(args.rtt_bounds[0], args.rtt_bounds[1])
else:
    ax.set_ylim(0, yUpperLim(df['mean_rtt']))

ax.plot('time', 'mean_rtt', data=df, label="Mean RTT", color="blue")

ax.set_xlabel("Time (s)")
ax.set_ylabel("RTT (ms)")
ax.grid()

fig.savefig(args.output_prefix + "-rtt.png", bbox_inches='tight')


### Rate ###
fig = plt.figure()
ax = fig.add_subplot(111)

if args.losses_bounds is not None:
    ax.set_ylim(args.losses_bounds[0], args.losses_bounds[1])
else:
    ax.set_ylim(0, yUpperLim(df['total_losses']))

ax.plot('time', 'total_losses', data=df, label="Total Losses", color="red")

ax.set_xlabel("Time (s)")
ax.set_ylabel("Losses")
ax.grid()

fig.savefig(args.output_prefix + "-losses.png", bbox_inches='tight')

