#!/bin/sh

set -e

base=`realpath $1`
srcdir=`pwd`

shift 1
cmakeExtra=("$@")
echo "cmake extra config=$cmakeExtra"

if [ ! -e $base ]
then
    echo $base 'does not exist'
    exit 1
fi

flow=(1 2 4)
noise_avg=("0.0" "0.1" "0.5" "1.0" "2.0" "3.0" "4.0" "5.0" "10.0" "15.0" "20.0")
noise_max=("0.0" "1.0" "5.0" "10.0" "10.0" "10.0" "10.0" "10.0" "15.0" "20.0" "25.0")
noise_prefix=("0" "0_1" "0_5" "1" "2" "3" "4" "5" "10" "15" "20")

run_sim() {
    local i=$1
    local j=$2

    local build="/tmp/mudt-sim-noise-build-${i}-${j}"
    local outdir=$base/${flow[i]}-flow/${noise_prefix[j]}-noise

    if [ -e $build ]
    then
        rm -rf $build
    fi

    mkdir $build
    cd $build

    echo "===== NUM_CLIENTS=${flow[i]}, NOISE AVG=${noise_avg[j]} ====="
    cmake -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS='-march=native' -DNUM_CLIENTS=${flow[i]} -DNOISE_AVG_PERC_DEV="${noise_avg[j]}" -DNOISE_MAX_PERC_DEV="${noise_max[j]}" "${cmakeExtra[@]}" $srcdir > /dev/null
    ninja > /dev/null
    ./simulation > /dev/null

    mkdir -p $outdir
    cp -rt $outdir data plots params.h
}

for i in `seq 0 $((${#flow[@]} - 1))`
do
    for j in `seq 0 $((${#noise_avg[@]} - 1))`
    do
        run_sim $i $j &
    done
done

wait

