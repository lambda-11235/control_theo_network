#!/usr/bin/env python3

import argparse

import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt

import seaborn as sns

parser = argparse.ArgumentParser(description="")
parser.add_argument('path', type=str,
        help="Path to data root.")
parser.add_argument('output_prefix', type=str,
        help="Prefix for output graphs.")
args = parser.parse_args()

noise_info = [(0.0, "0"), (0.1, "0_1"), (0.5, "0_5"), (1.0, "1"), (2.0, "2"),
        (3.0, "3"), (4.0, "4"), (5.0, "5"), (10.0, "10"), (15.0, "15"),
        (20.0, "20")]

df = pd.DataFrame()

for (noise, prefix) in noise_info:
    dataFile = f"{args.path}/{prefix}-noise/data/combined.csv"
    data = pd.read_csv(dataFile)
    data['noise'] = noise

    df = pd.concat([df, data], axis=0)


mpl.style.use('seaborn-bright')
mpl.rc('figure', dpi=200)


data = df.groupby('noise')
labels = [x[1]['noise'].mode()[0] for x in data]
rates = [x[1]['total_rate'] for x in data]
rtts = [x[1]['mean_rtt'] for x in data]
losses = [x[1]['total_losses'].max() for x in data]


### Rate ###
fig = plt.figure()
ax = fig.add_subplot(111)

ax.boxplot(rates, labels=labels, sym='ro')

ax.set_xlabel("Buffer Size (BDP)")
ax.set_ylabel("Total Rate (Gbps)")

fig.savefig(args.output_prefix + "-rate.png")


### RTT ###
fig = plt.figure()
ax = fig.add_subplot(111)

ax.boxplot(rtts, labels=labels, sym='ro')

ax.set_xlabel("Buffer Size (BDP)")
ax.set_ylabel("Mean RTT (ms)")

fig.savefig(args.output_prefix + "-rtt.png")


### Losses ###
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_yscale('log')

ax.plot(labels, losses)

ax.grid(which='both')
ax.set_xlabel("Buffer Size (BDP)")
ax.set_ylabel("Total Losses")

fig.savefig(args.output_prefix + "-losses.png")
