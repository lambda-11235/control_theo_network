#!/usr/bin/env python3

import argparse
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt

from common import *

parser = argparse.ArgumentParser(description="Plot")
parser.add_argument('data_file', type=str,
        help="The data file to plot from.")
parser.add_argument('output_prefix', type=str,
        help="Prefix for plot files.")
parser.add_argument('-s', '--subsamples', type=int,
        help="Number of subsamples to take (default: no subsampling).")
args = parser.parse_args()

df = pd.read_csv(args.data_file)
df = df.replace([-np.inf, np.inf], np.nan)

if args.subsamples is not None:
    df = subsampleByTime(df, args.subsamples)

mpl.style.use('seaborn-bright')
mpl.rc('figure', dpi=200)


### Rate ###
fig = plt.figure()
ax = fig.add_subplot(111)

ax.set_ylim(0, yUpperLim(df['setRate']))

ax.plot('time', 'setRate', data=df, label="Set Rate", color="blue")

ax.set_xlabel("Time (s)")
ax.set_ylabel("Rate (Gbps)")
ax.legend()

fig.savefig(args.output_prefix + "-rate.png", bbox_inches='tight')


### RTT ###
fig = plt.figure()
ax = fig.add_subplot(111)

ax.set_ylim(0, yUpperLim(df['rtt']))

ax.plot('time', 'rtt', data=df, label="RTT", color="blue")

ax.set_xlabel("Time (s)")
ax.set_ylabel("RTT (ms)")
ax.legend()

fig.savefig(args.output_prefix + "-rtt.png", bbox_inches='tight')


### Rate ###
fig = plt.figure()
ax = fig.add_subplot(111)

ax.set_ylim(0, yUpperLim(df['drops']))

ax.plot('time', 'drops', data=df, label="Losses", color="red")

ax.set_xlabel("Time (s)")
ax.set_ylabel("Losses")
ax.legend()

fig.savefig(args.output_prefix + "-losses.png", bbox_inches='tight')

