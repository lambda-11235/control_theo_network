
This directory contains files for plotting box plots of buffer data.
They take two arguments, which can be passed to gnuplot like so

```
> gnuplot -c rate.gp <IN_DIR> <OUT_FILE_PREFIX>
```

`<IN_DIR>` is expected to contain the files
`<IN_DIR>/{1_4,1_2,1,2,4}-bdp/data/combined.csv`.
