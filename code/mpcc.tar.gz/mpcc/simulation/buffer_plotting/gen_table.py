#!/usr/bin/env python3

import argparse
import json
import numpy as np
import pandas as pd

parser = argparse.ArgumentParser(description="")
parser.add_argument('output_csv', type=str,
        help="CSV to output table results to.")
parser.add_argument('path', type=str,
        help="Path to data root.")
args = parser.parse_args()

flows = [1, 2, 4, 8]
bufferSizes = ["1_16", "1_8", "1_4", "1_2", "1", "2", "4", "8", "16"]

df = pd.DataFrame()

for flow in flows:
    for bs in bufferSizes:
        dataFile = f"{args.path}/{flow}-flow/{bs}-bdp/data/combined.csv"
        data = pd.read_csv(dataFile)
        data['flow'] = flow
        data['bufSize'] = bs

        df = pd.concat([df, data], axis=0)

maxMeasures = ['total_losses', 'enqueues', 'dequeues', 'acks']

dfG = df.groupby(['flow', 'bufSize'])
df = dfG.median()
df[maxMeasures] = dfG[maxMeasures].max()
df['loss_perc'] = df['total_losses']/df['enqueues']

df.to_csv(args.output_csv)
