#!/usr/bin/env python3

import argparse

import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker

parser = argparse.ArgumentParser(description="")
parser.add_argument('path', type=str,
        help="Path to data root.")
parser.add_argument('output_prefix', type=str,
        help="Prefix for output graphs.")
args = parser.parse_args()

mpl.style.use('seaborn-bright')
mpl.rc('figure', dpi=200)
mpl.rc('boxplot.medianprops', color='#CC0000')


bufferSizes = [(1/16, "1/16", "1_16"), (1/8, "1/8", "1_8"), (1/4, "1/4", "1_4"),
        (1/2, "1/2", "1_2"), (1, "1", "1"), (2, "2", "2"), (4, "4", "4"),
        (8, "8", "8"), (16, "16", "16")]
order = [x[0] for x in bufferSizes]

df = pd.DataFrame()

for (bs, bss, bsp) in bufferSizes:
    dataFile = f"{args.path}/{bsp}-bdp/data/combined.csv"
    data = pd.read_csv(dataFile)
    data['bufSize'] = bs
    data['bufSizeStr'] = bss

    df = pd.concat([df, data], axis=0)


data = df.groupby('bufSize')
labels = [x[1]['bufSizeStr'].mode()[0] for x in data]
rates = [x[1]['total_rate'] for x in data]
rtts = [x[1]['mean_rtt'] for x in data]
losses = [x[1]['total_losses'].max()/x[1]['enqueues'].max() for x in data]

rtts = [x.loc[x > 25] for x in rtts]


#def splitSub(data):
#    q1, q3 = data.quantile([0.25, 0.75])
#    lower = q1 - 2*1.5*(q3-q1)
#    upper = q3 + 2*1.5*(q3-q1)
#    cond = data <= upper
#    return (data.loc[cond], data.loc[~cond])
#
#def split(data):
#    return zip(*map(splitSub, data))


### Rate ###
fig = plt.figure()
ax = fig.add_subplot(111)

ax.boxplot(rates, labels=labels, whis='range')

ax.set_xlabel("Buffer Size (BDP)")
ax.set_ylabel("Total Rate (Gbps)")
ax.set_ylim(0, 80)
ax.grid()

fig.savefig(args.output_prefix + "-rate.png", bbox_inches='tight')


### RTT ###
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_yscale('log')

ax.boxplot(rtts, labels=labels, whis='range')

ax.set_xlabel("Buffer Size (BDP)")
ax.set_ylabel("Mean RTT (ms)")
ax.grid(which='both')

formatter = mpl.ticker.ScalarFormatter()
ax.get_yaxis().set_minor_formatter(formatter)
ax.get_yaxis().set_major_formatter(formatter)

fig.savefig(args.output_prefix + "-rtt.png", bbox_inches='tight')


### Losses ###
fig = plt.figure()
ax = fig.add_subplot(111)

ax.ticklabel_format(axis='y', scilimits=(-2,2))
ax.plot(labels, losses)

ax.set_xlabel("Buffer Size (BDP)")
ax.set_ylabel("Total Losses (as fraction of packets sent)")
ax.grid(which='both')

fig.savefig(args.output_prefix + "-losses.png", bbox_inches='tight')
