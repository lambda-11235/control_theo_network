#!/bin/sh

set -e

base=`realpath $1`
srcdir=`pwd`

shift 1
cmakeExtra=("$@")
echo "cmake extra config=$cmakeExtra"

if [ ! -e $base ]
then
    echo $base 'does not exist'
    exit 1
fi

flow=(1 2 4 8)
bdp_set=("/16" "/8" "/4" "/2" "" "*2" "*4" "*8" "*16")
bdp_prefix=("1_16" "1_8" "1_4" "1_2" "1" "2" "4" "8" "16")

flow_max=3
bdp_max=8

run_sim1() {
    local i=$1
    local j=$2

    local build="/tmp/mudt-sim-build-${i}-${j}"
    local outdir=$base/${flow[i]}-flow/${bdp_prefix[j]}-bdp

    if [ -e $build ]
    then
        rm -rf $build
    fi

    mkdir $build
    cd $build

    echo "===== RUN, NUM_CLIENTS=${flow[i]}, BUFFER_LENGTH=(BUF_DELAY_PROD${bdp_set[j]}) ====="
    cmake -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS='-march=native' -DNUM_CLIENTS=${flow[i]} -DBUFFER_LENGTH="(BUF_DELAY_PROD${bdp_set[j]})" "${cmakeExtra[@]}" $srcdir > /dev/null
    ninja > /dev/null
    ./simulation > /dev/null

    echo "===== COPY DATA, NUM_CLIENTS=${flow[i]}, BUFFER_LENGTH=(BUF_DELAY_PROD${bdp_set[j]}) ====="
    mkdir -p $outdir
    cp -rt $outdir data params.h
}

for i in `seq 0 $flow_max`
do
    for j in `seq 0 $bdp_max`
    do
        run_sim1 $i $j &
    done
done

wait
