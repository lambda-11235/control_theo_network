
#include <algorithm>
#include <iostream>
#include <climits>

#include "MPCCC.h"

inline double sqr(double x) {
    return x*x;
}


void MPCCC::init() {
    numObs = 1 << 6;
    period = std::chrono::seconds(30);
    weight = 0.25;
    learnRate = 10.0;
    rateDiff = 1.0;

    alpha = 0.1;
    c1 = 1.0;
    c2 = 1.0e-3;
    c3 = 1.0e-2;

    lossLast = 0;

    m_dCWndSize = INT_MAX;
    m_dPktSndPeriod = 0.0;

    reset();
}

void MPCCC::reset() {
    lastResetTime = mpc_now();

    a = 0;
    rB = 0;
    lB = 0;
    lP = MPC_INF;

    avgRate = 0;
    avgRTT = 0;

    rates.clear();
    rtts.clear();
    xs.clear();

    for (size_t i = 0; i < numObs; i++) {
        rates.push_back(0);
        rtts.push_back(0);
        xs.push_back(0);
    }
}


void MPCCC::onPktSent(const CPacket* pkt) {
    const UDT::TRACEINFO *info = getPerfInfo();
    double rateMeas = info->mbpsSendRate;
    double rttMeas = info->msRTT;

    update(rateMeas, rttMeas, info->pktSndLoss - lossLast);

    if (period <= mpc_now() - lastResetTime) {
        rateOpt = rB*7/8;
        lossLast = info->pktSndLoss;
        reset();
        rB = rateOpt;
    } else {
        if (avgRTT != 0)
            c1 = sqr(avgRate)/avgRTT;

        rateOpt = (c1*rB*(1.0 - alpha*xs[0]) + sqr(rB)*(c2*rates[0] + c3/2.0))/(c2*sqr(rB) + c1);
    }

    rateOpt = std::min(std::max(MPC_MIN_RATE, rateOpt), MPC_MAX_RATE);

    double xhat = xs[0] + (rateMeas - rB)/rB;
    xhat = std::min(std::max(0.0, xhat), lB - lP);
    predRTT = a/rateOpt + lP + xhat;

    //m_dCWndSize = rateOpt*rttMeas/m_iMSS;
    //m_dPktSndPeriod = m_iMSS/rateOpt;
}


void MPCCC::update(double rateMeas, double rttMeas, double losses) {
    pushPop(rates, rateMeas);
    pushPop(rtts, rttMeas);

    /* Ignore for now
    Eigen::MatrixXd A(numObs, 2);
    Eigen::MatrixXd b(numObs, 1);

    for (size_t i = 0; i < numObs; i++) {
        if (rates[i] != 0)
            A(i, 0) = 1.0/rates[i];
        else
            A(i, 0) = 0.0;

        A(i, 1) = 1.0;
        b(i) = rtts[i] - lP;
    }

    Eigen::MatrixXd x = A.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(b);
    double aNew = x(0);

    if (aNew >= 0)
        a = aNew;
    */

    lB = std::max(lB, rttMeas);
    lP = std::min(lP, rttMeas);

    rttMeas *= losses + 1;

    if (rateMeas != 0.0)
        pushPop(xs, std::max(0.0, rttMeas - a/rateMeas - lP));

    if (rateMeas != 0.0) {
        rB += learnRate*2*(xs[1] + (rateMeas - rB)/rateMeas - rttMeas + lP)/rateMeas;
        rB = std::max(0.0, rB);
    }

    avgRate = wma(avgRate, rateMeas);
    avgRTT = wma(avgRTT, rttMeas);
}
