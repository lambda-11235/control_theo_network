
#include <chrono>
#include <deque>
#include <vector>
#include <udt/udt.h>
#include <udt/ccc.h>

#ifndef MPC_CC_H
#define MPC_CC_H

#define MPC_MIN_RATE 1.0
#define MPC_MAX_RATE 1.0e6

#define MPC_INF 1.0e10

typedef std::chrono::time_point< std::chrono::high_resolution_clock > mpc_time_point;

inline mpc_time_point mpc_now() {
    return std::chrono::high_resolution_clock::now();
}


class MPCCC : public CCC {
    private:
        size_t numObs;
        std::chrono::duration<double> period;
        double weight;
        double learnRate;
        double rateDiff;
        long lossLast;

        double alpha;
        double c1;
        double c2;
        double c3;

        mpc_time_point lastResetTime;

        double a;
        double rB;
        double lB;
        double lP;
        double rateOpt;
        double predRTT;

        double avgRate;
        double avgRTT;

        std::deque<double> rates;
        std::deque<double> rtts;
        std::deque<double> xs;

    public:
        void init();
        void close() {}
        void onACK(const int& ack) {}
        void onLoss(const int* losslist, const int& size) {}
        void onTimeout() {}
        void onPktSent(const CPacket* pkt);
        void onPktReceived(const CPacket* pkt) {}
        void processCustomMsg(const CPacket& pkt) {}

        const double getA() { return a; }
        const double getLP() { return lP; }
        const double getLB() { return lB; }
        const double getRB() { return rB; }
        const double getX() { return xs[0]; }
        const double getRateOpt() { return rateOpt; }
        const double getPredRTT() { return predRTT; }

        void reset();

    private:
        void update(double rateMeas, double rttMeas, double losses);

        void pushPop(std::deque<double> &q, double x) {
            q.push_front(x);
            q.pop_back();
        }

        double wma(double avg, double x) {
            return (1.0 - weight)*avg + weight*x;
        }
};

#endif /* end of include guard: MPC_CC_H */
