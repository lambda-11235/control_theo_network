#!/usr/bin/env python
'''
This test the model in a mathematical fashion. It is a revision of
test_controller.py to work with the current controller and offer more modes of
responses.

@author: Taran Lynn
@contact: tflynn@ucdavis.edu

'''

from controller import Controller

import argparse
import math
import matplotlib
import matplotlib.pyplot as plt
import queue
import random

LR = 0.01
C1 = 1/8
C2 = (1 - C1)/2
C3 = (1 - C1)/2
W = 1.0/8.0
PROBE_RTTS = 2
STABLE_RTTS = 128
BUFFER_FILL = 1/8

NUM_DATA_POINTS = 100000
BOTTLENECK_RATE = 15
TRANS_DELAY = 5
BUFFER_LENGTH = 100

parser = argparse.ArgumentParser(description = "Run a test.")
parser.add_argument('-l', '--learning-rate', type=float, default=LR,
        help="")
parser.add_argument('--c2', type=float, default=C2,
        help="")
parser.add_argument('--c3', type=float, default=C3,
        help="")
parser.add_argument('-w', '--avg-weight', type=float, default=W,
        help="")
parser.add_argument('--probe-rtts', type=int, default=PROBE_RTTS,
        help="")
parser.add_argument('--stable-rtts', type=int, default=STABLE_RTTS,
        help="")
parser.add_argument('--buffer-fill', type=float, default=BUFFER_FILL,
        help="How full the bottleneck buffer should be.")
parser.add_argument('-N', '--num-clients', type=int, default=1,
        help="")
parser.add_argument('-n', '--num-samples', type=int, default=NUM_DATA_POINTS,
        help="")
parser.add_argument('-b', '--bottleneck-rate', type=float, default=BOTTLENECK_RATE,
        help="")
parser.add_argument('-t', '--trans-delay', type=float, default=TRANS_DELAY,
        help="")
parser.add_argument('-g', '--buffer-length', type=int, default=BUFFER_LENGTH,
        help="")
parser.add_argument('-v', '--verbose', action='store_true',
        help="Print additional information.")
args = parser.parse_args()

matplotlib.rc('font', size=22)


def mean(x):
    return sum(x)/len(x)

def trackingList():
    return [[0] for _ in range(args.num_clients)]


if args.verbose:
    print("Using LR = {}, C2 = {}, C3 = {}, W = {}, DOWN_RTTS = {}, UP_RTTS = {}, BUFFER FILL = {}".format(
        args.learning_rate, args.c2, args.c3, args.avg_weight, args.probe_rtts,
        args.stable_rtts, args.buffer_fill))


controllers = []
for _ in range(args.num_clients):
    controllers.append(Controller(
        args.bottleneck_rate/4, args.bottleneck_rate*8,
        args.learning_rate, args.c3, args.c3,
        args.avg_weight, args.probe_rtts, args.stable_rtts,
        args.buffer_fill))

recorded_time = trackingList()
recorded_latency = trackingList()
predicted_latency = trackingList()
recorded_rate = trackingList()
x = trackingList()
rB = trackingList()
lP = trackingList()
lB = trackingList()
lsd = trackingList()
drops = trackingList()
sent = [0]*args.num_clients

buf = queue.deque()
nextPacketTimes = queue.deque()

enqueues = [0]*args.num_clients
dequeueTime = 0

time = 0
cnt = args.num_samples
lastPercComplete = 0
while cnt > 0:
    if args.verbose:
        print("Time = {}, Dequeue Time = {}, Enqueue Times = {}, Buffer Length = {}, Drops = {}".format(
            time, dequeueTime, enqueues, len(buf), sum(drops)))

    if len(buf) > 0 and dequeueTime <= time:
        cnt -= 1
        percComplete = 100*(args.num_samples - cnt)/args.num_samples

        if percComplete >= lastPercComplete + 0.1:
            print("\r{:.1f}% complete".format(percComplete), end='')

        (i, queueTime) = buf.pop()
        rate = args.bottleneck_rate
        rate -= min(random.expovariate(16/args.bottleneck_rate), args.bottleneck_rate/2)
        dequeueTime = time + 1/rate

        recorded_time[i].append(time)
        recorded_latency[i].append(time - queueTime + args.trans_delay)

        res = controllers[i].process(time, recorded_rate[i][-1], recorded_latency[i][-1], drops[i][-1])
        drops[i].append(0)
        recorded_rate[i].append(res[0])
        predicted_latency[i].append(res[1])

        x[i].append(controllers[i].l0 - controllers[i].lP)
        rB[i].append(controllers[i].rB)
        lP[i].append(controllers[i].lP)
        lB[i].append(controllers[i].lB)
        lsd[i].append(controllers[i].stdRTT)

    if len(buf) > 0:
        nextTime = dequeueTime
    else:
        nextTime = enqueues[0]

    for i in range(args.num_clients):
        if enqueues[i] <= time:
            sent[i] += 1

            if len(buf) < args.buffer_length:
                buf.appendleft((i, time))
            else:
                drops[i][-1] += 1

            enqueues[i] = time + 1/controllers[i].getRate()

        nextTime = min(nextTime, enqueues[i])

    time = nextTime

for i in range(args.num_clients):
    print("")
    print("For client {}".format(i))
    print("Mean rB = {}".format(mean(rB[i])))
    print("Mean lP = {}".format(mean(lP[i])))
    print("Mean lB = {}".format(mean(lB[i])))
    print("Mean stdRTT = {}".format(mean(lsd[i])))
    print("Mean RTT = {}".format(mean(recorded_latency[i])))
    print("Mean Rate = {}".format(mean(recorded_rate[i])))
    print("Drops = {}".format(sum(drops[i])))
    print("% Droped = {:.1f}".format(100*sum(drops[i])/sent[i]))


    fig = plt.figure()

    axRate = fig.add_subplot(111)
    axRTT = axRate.twinx()

    axRate.plot(
        recorded_time[i], rB[i], 'g-',
        recorded_time[i], recorded_rate[i], 'ob')
    axRate.legend(['rB', 'Pacing Rate'])
    axRate.set_title('Simulation for Controller {}'.format(i))
    axRate.set_xlabel('Time step')
    #axRate.set_ylabel('Arbitrary units')
    axRate.set_ylim(args.bottleneck_rate/5, args.bottleneck_rate*9)

    axRTT.plot(
        #recorded_time[i], x[i], 'c-',
        recorded_time[i], lP[i], '-b',
        recorded_time[i], lB[i], '^y',
        recorded_time[i], lsd[i], '-p',
        #recorded_time[i], predicted_latency[i], 'oc',
        recorded_time[i], recorded_latency[i], '--r')
    #axRTT.legend(['lP', 'lB', 'RTT Var', 'Pred. RTT', 'RTT'])
    axRTT.legend(['lP', 'lB', 'RTT Var', 'RTT'])
    #axRTT.set_ylabel('Arbitrary units')

    minRTT = args.trans_delay - args.buffer_length/args.bottleneck_rate
    maxRTT = args.trans_delay + args.buffer_length/args.bottleneck_rate
    axRTT.set_ylim(3*minRTT/4, 3*maxRTT/2)

    fig = plt.figure()
    axDrops = fig.add_subplot(111)
    axDrops.plot(recorded_time[i], drops[i], '-r')
    axDrops.set_title("Drops for Controller {}".format(i))
    axDrops.set_xlabel('Time step')
    axDrops.set_ylabel('Drops')

plt.show()
