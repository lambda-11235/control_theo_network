#!/usr/bin/env python

import argparse
import pandas as pd
import matplotlib.pyplot as plt

bwctlStartTime = 0

parser = argparse.ArgumentParser(description="Prints stats and plots test results.")
parser.add_argument('test', type=str,
        help="The name of the test to run.")
parser.add_argument('-o', '--output', type=str,
        help="Sets output file base name.")
parser.add_argument('-e', '--output-extension', type=str, default="pdf",
        help="Sets the extension for output files (i.e. pdf, png, etc.).")
parser.add_argument('-q', '--limit-quantile', type=float,
        help="Limits output range to within double of a certain quantile.")
parser.add_argument('-n', '--no-plot', action='store_true',
        help="Disables plots and only prints statistics.")
args = parser.parse_args()


data = pd.read_json(args.test)
data = data.reindex(columns = ['time', 'rate', 'rtt', 'loss', 'flight', 'a', 'lP',
    'lB', 'rB', 'x', 'rateOpt', 'predRTT'], fill_value=0.0)
print(data.describe())

if args.no_plot:
    exit()

fig, axs = plt.subplots(3, 2, figsize=(10, 10))
ax1 = axs[0][0]
ax2 = ax1.twinx()
ax3 = axs[0][1]
ax4 = ax3.twinx()
ax5 = axs[1][0]
ax6 = ax5.twinx()
ax7 = axs[1][1]
ax8 = ax7.twinx()
ax9 = axs[2][0]
ax10 = ax9.twinx()

ax1.plot(data.time, data.rtt, 'b')
ax1.set_ylabel("RTT (ms)")

ax2.plot(data.time, data.predRTT, 'r')
ax2.set_ylabel("predRTT (ms)")

ax3.plot(data.time, data.lB, 'b')
ax3.set_ylabel("lB (ms)")

ax4.plot(data.time, data.lP, 'r')
ax4.set_ylabel("lP (ms)")

ax5.plot(data.time, data.x, 'b')
ax5.set_ylabel("x (ms)")

ax6.plot(data.time, data.rB, 'r')
ax6.set_ylabel("rB (mbps)")

ax7.plot(data.time, data.rateOpt, 'b')
ax7.set_ylabel("rate set (mbps)")

ax8.plot(data.time, data.rate, 'r')
ax8.set_ylabel("rate (mbps)")

ax9.plot(data.time, data.loss, 'b')
ax9.set_ylabel("losses")

ax10.plot(data.time, data.a, 'r')
ax10.set_ylabel("a")

if args.limit_quantile is not None:
    ax1.set_ylim(0, 2*data.rtt.quantile(args.limit_quantile))
    ax2.set_ylim(0, 2*data.rtt.quantile(args.limit_quantile))
    ax3.set_ylim(0, 2*data.lB.quantile(args.limit_quantile))
    ax4.set_ylim(0, 2*data.lP.quantile(args.limit_quantile))
    ax5.set_ylim(0, 2*data.x.quantile(args.limit_quantile))
    ax6.set_ylim(0, 2*data.rB.quantile(args.limit_quantile))
    ax7.set_ylim(0, 2*data.rate.quantile(args.limit_quantile))
    ax8.set_ylim(0, 2*data.rate.quantile(args.limit_quantile))
    ax9.set_ylim(0, 2*data.loss.quantile(args.limit_quantile))
    ax10.set_ylim(0, 2*data.a.quantile(args.limit_quantile))

if args.output is not None:
    plt.savefig(args.output + "." + args.output_extension)
else:
    plt.show()
