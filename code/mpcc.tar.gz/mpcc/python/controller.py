
from math import *

INF = 1000

# Approximation of 0 RTT.
LOW_THRESH_RTT = 1.0e-8

LP_MODE = 'LP MODE'
LB_MODE = 'LB MODE'
STABLE_MODE = 'STABLE MODE'


def wma(weight, avg, x):
    return (1 - weight)*avg + weight*x


class Controller:
    def __init__(self, minRate, maxRate, lr, c2, c3, weight, probeRTTs,
        stableRTTs, bufferFill):
        self.minRate = minRate
        self.maxRate = maxRate

        self.lr = lr
        self.c1 = 1 - c2 - c3
        self.c2 = c2
        self.c3 = c3
        self.weight = weight
        self.probeRTTs = probeRTTs
        self.stableRTTs = stableRTTs
        self.bufferFill = bufferFill

        self.lastTime = 0

        self.reset()

    def reset(self):
        self.probingMode = STABLE_MODE
        self.probeTimeout = 0

        self.r = self.maxRate
        self.lhat = 0
        self.l0 = 0
        self.l1 = 0
        self.avgRTT = 0
        self.varRTT = 0
        self.stdRTT = 0

        self.rB = 0
        self.lB = 0
        self.lP = INF

    def getRate(self):
        return self.r

    def process(self, time, r, l, drops):
        # Ignore outliers, but still update stats with a clamped value.
        # Updating stats this way ensures the average comes into line if we do
        # experience a real sudden change in RTT behavior.

        timeDelta = time - self.lastTime
        self.lastTime = time

        if self.outlier(l):
            low = self.avgRTT/2
            high = self.avgRTT*3/2
            l = min(max(low, l), high)

        self.update_stats(self.r, l)

        if self.outlier(l):
            return (self.r, self.lhat)

        lt = self.handle_probing(time, self.r, l)

        if self.probingMode == LP_MODE:
            self.r = self.minRate
        elif self.probingMode == LB_MODE:
            self.r = self.maxRate
        else:
            self.update_rb(timeDelta, self.r, l)

            l *= (drops + 1)

            tmp1 = self.c3*self.lP**2
            tmp2 = self.weight*self.c2 + self.c1
            L = tmp2*(l - timeDelta) - self.c1*lt - self.weight*self.c2*self.avgRTT
            denom = tmp1 + timeDelta**2*tmp2

            if denom != 0:
                self.r = (tmp1*self.r - timeDelta*self.rB*L)/denom
            else:
                self.r = self.r

            self.r = min(max(self.minRate, self.r), self.maxRate)

        self.lhat = self.l0
        if self.rB > 0:
            self.lhat += (r - self.rB)/self.rB
        self.lhat = min(max(self.lP, self.lhat), self.lB)

        return (self.r, self.lhat)

    def handle_probing(self, time, r, l):
        """
        Handles probing mode switching. This will update lP and return a target
        RTT.
        """
        if self.probeTimeout <= time:
            if self.probingMode == LP_MODE:
                self.lB = l
                self.probingMode = LB_MODE
            elif self.probingMode == LB_MODE:
                self.probingMode = STABLE_MODE
            else:
                self.lP = l
                self.probingMode = LP_MODE

            if self.probingMode != STABLE_MODE:
                self.probeTimeout = time + self.probeRTTs*self.avgRTT
            else:
                self.probeTimeout = time + self.stableRTTs*self.avgRTT

        # Set target RTT to appropriate value.
        if self.probingMode != STABLE_MODE and not self.outlier(l):
                self.lP = min(l, self.lP)
                self.lB = max(l, self.lB)

        lt = self.lP + (self.lB - self.lP)*self.bufferFill

        return lt

    def update_rb(self, timeDelta, r, l):
        """
        Update estimates of x and rB.
        """
        self.l1 = self.l0
        self.l0 = l

        # Estimate rB
        if self.rB > 0:
            t1 = (self.l1 - self.l0 - timeDelta)*self.rB + r*timeDelta
            t = r*timeDelta*t1/self.rB**3
        else:
            t = 1.0

        self.rB += self.lr*t

        # Exact solution
        #t = timeDelta + self.l0 - self.l1
        #if t != 0:
        #    self.rB = (1 - self.lr)*self.rB + self.lr*r*timeDelta/t

        self.rB = min(max(self.minRate, self.rB), self.maxRate)

    def outlier(self, rtt):
        diff = abs(self.avgRTT - rtt)
        return self.stdRTT > LOW_THRESH_RTT and diff > self.avgRTT/2 and diff > 3*self.stdRTT

    def update_stats(self, r, l):
        """
        Update rate and RTT statistics (running average and variance).
        """

        self.avgRTT = wma(self.weight, self.avgRTT, l)
        self.varRTT = wma(self.weight, self.varRTT, (l - self.avgRTT)**2)
        self.stdRTT = sqrt(self.varRTT)
